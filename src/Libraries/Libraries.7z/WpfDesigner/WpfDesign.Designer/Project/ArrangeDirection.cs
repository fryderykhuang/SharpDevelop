﻿namespace ICSharpCode.WpfDesign.Designer
{
    public enum ArrangeDirection
    {
        Top,
        VerticalMiddle,
        Bottom,
        Left,
        HorizontalMiddle,
        Right,
    }
}
